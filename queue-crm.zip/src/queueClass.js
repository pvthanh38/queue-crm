'use strict'
let settings = require('./libs/settings');
let Queue = require('bull');
let queue_crm = new Queue('queue-1', settings.bull.redis_url);
const fs = require('fs')
class queueClass {
	constructor() {
		
	}
	validate(body) {
		if(!body.type || body.type == ""){
			return JSON.stringify({ status: 500, msg: "field type not null" });
		}
		if(body.type == 'mail'){
			if(body.email == '' || body.content == ""){
				return JSON.stringify({ status: 500, msg: "field email and content not null EX: { \"content\":\"Hello there\",\"email\":\"test@gmail.com\",\"subject\":\"Viết plugin Test\",\"type\":\"mail\"}" });
			}
		}
		if(body.type == 'slack'){
			if(body.conversationId == '' || body.content == ""){
				return JSON.stringify({ status: 500, msg: "field conversationId and content not null EX: { \"content\":\"Hello there\",\"conversationId\":\"U6YBYUSL9\",\"user\":\"U6YBYUSL9\",\"type\":\"slack\"}" });
			}
		}
		return true;
	}
	
	add(data) {
		var validate = this.validate( data );
		if(validate == true){
			queue_crm.add({body: data}).then(job => {
				console.log("da them " + job.id);
				fs.writeFile('queue/log-'+job.id+'.txt', JSON.stringify(data) , function(err) {
					if (err) {
						console.log("error write queue");
					}
					
				});
				
				return ;
			}).catch(err => {
				console.error('err', err);
				return false
			});
		}else{
			return validate;
		}
		
	}
	
}

module.exports = queueClass;