'use strict'
var request = require('request');
let Queue = require('bull');
const queueClass = require('./queueClass');
let settings = require('./libs/settings');
let queue_crm = new Queue('queue-1', settings.bull.redis_url);
class apiClass {
	constructor(apiKey) {
		this.apiKey = apiKey;
		this.base = "http://localhost:4444";
		this.version = "/v1";
		this.API_TODO = "/api/todo";
	}
	
	httpPost(endpoint, data) {
		data.apiKey = this.apiKey;
		var url = this.base + endpoint + this.version;
		const classQueue = new queueClass();
		switch (endpoint) {
			case this.API_TODO:
				var addQueue = classQueue.add(data); return addQueue;
				break;
			default:
				var addQueue = classQueue.add(data); return addQueue;
				break;
		}

	}
	send(data, endpoint) {
		var post = this.httpPost( endpoint, data );
		return post;
	}
	/*getProject(name) {
		return this.projects[name];
	}*/
}

module.exports = apiClass;