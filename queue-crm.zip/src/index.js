'use strict'

const express = require('express')
const { WebClient } = require('@slack/client');
const fs = require('fs')
const port = process.env.PORT || 4444
var path = require('path');
let settings = require('./libs/settings');
let Queue = require('bull');
var rand = require("random-key");
const app = express()
const apiClass = require('./apiClass');
//
var bodyParser = require('body-parser');

//app.use(express.bodyParser());
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true }));
const nodemailer = require('nodemailer');
app.use(function( req, res, next ) {
	var data = '';
	req.on('data', function( chunk ) {
		data += chunk;
	});
	if(req.body == ""){
		req.on('end', function() {
			req.rawBody = data;
			if (data && data.indexOf('{') > -1 ) {
				req.body = JSON.parse(data);
			}
			next();
		});
	}
	next();
});

// HANDLER QUEUE WHEN TURN OFF APP
let queue_crm = new Queue('queue-1', settings.bull.redis_url);
const directoryPath = path.join(__dirname, 'queue');
fs.readdir(directoryPath, function (err, files) {
	//handling error
	if (err) {
		return console.log('Unable to scan directory: ' + err);
	}
	if(files.length > 0){
		files.forEach(function (file) {
			var ob = JSON.parse(fs.readFileSync(directoryPath+'/'+file, 'utf8'));
			queue_crm.add({body: ob}).then(job => {
				fs.writeFile(directoryPath+'/log-'+job.id+'.txt', JSON.stringify(ob) , function(err) {
					if (err) {
						console.log("error write queue");
					}
					fs.unlink(directoryPath+'/'+file, (err) => {
						if (err) throw err;
							console.log(directoryPath+'/'+file+' deleted');
					});
				});
				return ;
			}).catch(err => {
				console.error('err', err);
			});
		});
	}
});
app.post('/api/todo', async (req, res, next) => {
	res.setHeader('Content-Type', 'application/json');
	if(validate(req.body, res) == true) {
		queue_crm.add({body: req.body}).then(job => {
			//console.log("da them " + job.id);
			fs.writeFile('queue/log-'+job.id+'.txt', JSON.stringify(req.body) , function(err) {
				if (err) {
					//console.log("error write queue");
				}
				//console.log("write queue success");
			});
			res.end(JSON.stringify({ status: 200, msg: "success" }));
			//queue_crm.close();
			return ;
		}).catch(err => {
			console.error('err', err);
			res.end(JSON.stringify({ status: 500, msg: err }));
		});
	}
	
	
})
queue_crm.process(async (job, done) => {
	setTimeout(async () => {
		if(job.data.body.type == 'mail'){
			send_mail(job.data.body, job.id);
		}
		if(job.data.body.type == 'slack'){
			send_slack(job.data.body, job.id);
		}
		if(job.data.body.type == 'log'){
			write_log(job.data.body);
		}
		
		done();
	}, 5000);
});

function send_slack(body, job_id){
	const token = settings.bull.token_slack;
	const web = new WebClient(token);
	// This argument can be a channel ID, a DM ID, a MPDM ID, or a group ID
	const conversationId = body.conversationId;
	// See: https://api.slack.com/methods/chat.postMessage
	web.chat.postMessage({ channel: conversationId, text: body.content, as_user: body.user })
		.then((res) => {
		fs.unlink('queue/log-'+job_id+'.txt', (err) => {
			if (err) throw err;
				console.log('queue/log-'+job_id+'.txt deleted');
		});
	})
	.catch(console.error);
}

function write_log(body){
	fs.writeFile('logs/log-'+rand.generate()+'.txt', body.content , function(err) {
		if (err) {
			console.log("error");
		}
		console.log("success");
	});
}

function send_mail(body, job_id){
	var smtpConfig = {
		host: 'smtp.gmail.com',
		port: 465,
		secure: true,
		auth: {
			user: settings.bull.email,
			pass: settings.bull.pass
		}
	};
	var transporter = nodemailer.createTransport(smtpConfig);
	var mailOptions = {
		from: '"Task Mới" <https://hotro.vantaymedia.vn/admin/>', // sender address
		to: body.email, // list of receivers
		subject: body.subject, // Subject line
		text: body.content, // plaintext body
		html: '' // html body
	};
	
	// send mail with defined transport object
	transporter.sendMail(mailOptions, function(error, info){
		
		if(error){
			console.log(error);
			return false ;
		}
		fs.unlink('queue/log-'+job_id+'.txt', (err) => {
			if (err) throw err;
				console.log('queue/log-'+job_id+'.txt deleted');
		});
		return true ;
	});	
}
function validate(body, res) {
		if(!body.type || body.type == ""){
			res.end(JSON.stringify({ status: 500, msg: "field type not null" }));
		}
		if(body.type == 'mail'){
			if(body.email == '' || body.content == ""){
				res.end(JSON.stringify({ status: 500, msg: "field email and content not null EX: { \"content\":\"Hello there\",\"email\":\"test@gmail.com\",\"subject\":\"Viết plugin Test\",\"type\":\"mail\"}" }));
			}
		}
		if(body.type == 'slack'){
			if(body.conversationId == '' || body.content == ""){
				res.end(JSON.stringify({ status: 500, msg: "field conversationId and content not null EX: { \"content\":\"Hello there\",\"conversationId\":\"U6YBYUSL9\",\"user\":\"U6YBYUSL9\",\"type\":\"slack\"}" }));
			}
		}
		return true;
	}


app.listen(port, () => {
	console.info(`Listen port on ${port}.`)
})
// Terminate process
process.on('SIGINT', () => {
    process.exit(0)
})